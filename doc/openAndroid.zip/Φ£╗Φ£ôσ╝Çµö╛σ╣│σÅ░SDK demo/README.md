蜻蜓 OPEN SDK Quick Start
========

| 错误码 | 错误消息 | 解释 |
| :-- | :-- | :-- |
| 0 | Success | 成功返回结果 |
| 10000 | Internal Error | 服务器内部错误 |
| 10001 | Channel Access Not Allow | 对该专辑无权限访问 |
| 10002 | Limit Excced | 访问频次超过限制 |
| 10003 | Auth Failure | 认证失败 |
| 10004 | Item already purchased | 重复购买的错误消息 |
| 10005 | User Not Exist | 用户不存在 |
| 10006 | User Not Login | 用户未登录 |
| 10007 | Channel Not Exist | 该专辑不存在 |
| 10008 | Empty Device ID | 缺少device Id参数 |
| 10009 | Invalid page or pagesize | 页码或页容量非法 |
| 10010 | Already refunded | 商品已退款，勿重复退款 |
| 10011 | Invalid Param | 参数错误 |
| 10012 | Get Audio Resource Failed | 获取音频资源失败 |
| 10013 | Audio not purchased by user | 该音频未购买 |
| 10014 | Not Purchased, return free audio | 音频未购买，返回免费试听节目 |
| 10015 | No Free Audio | 无试听节目 |
| 10016 | Transcoding, please retry later | 音频转码中，请稍后重试 |
| 20000 | No NetWork | 网络异常 |
| 20001 | Miss Auth Request | 授权请求缺失 |
| 20002 | Miss Auth RedirectUrl | 授权回调地址缺失 |
| 20003 | Refresh Token fail| token刷新失败 |



- [1. 初始化](#初始化)
	- [1.1 初始化代码](#初始化代码)
	- [1.2 需求权限](#需求权限)
- [2. 授权](#授权)
	- [2.1 授权启动](#授权启动)
	- [2.2 授权回调](#授权回调)
	- [2.3 授权移除](#授权移除)
	- [2.4 第三方账号登陆](#第三方账号登陆)
- [3. 用户信息](#用户信息) 
- [4. 支付](#支付)
- [5. 播放器](#播放器)
- [6. 常用接口](#常用接口描述)


初始化
--------
### 初始化代码
引用蜻蜓sdk的模块的build.gradle配置：
 compileSdkVersion 27及以上
```
repositories {
   maven {
               url uri('http://maven.qingting.fm/')
           }
}
dependencies {
     compile 'fm.qingting.open.android:qtsdkplayer:0.1.4'
     compile 'fm.qingting.open.android:qtsdk:0.1.4'
     }

```
首先通过蜻蜓官方渠道获取用于初始化SDK的 Client Id 以及 Client Secret参数。
然后新建一个名字叫做 MyQTApplication  Java Class ,让它继承自 Application 类，代码如下:
```java
public class MyQTApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
 @Override
    public void onCreate() {
        super.onCreate();
        QTSDK.setHost("服务器地址");
        // 初始化参数依次为 this, ClientId, ClientSecret
        QTSDK.init("TEST_CLIEND_ID","TEST_CLIEND_SECRET");
        QTSDK.setAuthRedirectUrl("http://qttest.qingting.fm");
     }
}
 
```
### 需求权限
打开 AndroidManifest.xml 文件来配置 SDK 所需要的手机的访问权限以及配置 MyQTApplication 类：
```xml
<!-- 蜻蜓opensdk权限声明 START -->
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.READ_PHONE_STATE" />
<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
<!-- 权限声明 END -->

<application
  android:name=".MyQTApplication" >


</application>
```


授权
--------
### 授权启动
蜻蜓基于OAuth2.0授权模式，如调用者后端需要回调可以通过设置回调地址实现：

```java
QTSDK.setAuthRedirectUrl(url);
```

授权方式分为web授权与唤起蜻蜓app授权两种方式，参考示例如下：
```java
//启动web授权
QTSDK.startWebAuthorize(getActivity(), new QTAuthCallBack() {
    @Override
    public void onComplete(QTAuthResponse response) {
        //授权成功
    }

    @Override
    public void onException(QTException e) {
        //授权异常，具体查看异常code
    }

    @Override
    public void onCancel() {
        //用户取消授权
    }
});

//先尝试启动蜻蜓app，如果失败则自动启动web授权
QTSDK.startAuthorize(getActivity(), new QTAuthCallBack() {
    @Override
    public void onComplete(QTAuthResponse response) {
        //授权成功
    }

    @Override
    public void onException(QTException e) {
        //授权异常，具体查看异常code
    }

    @Override
    public void onCancel() {
        //用户取消授权
    }
});
```



### 授权移除
使用者可以调用clear方法清除本地授权.
```java
QTSDK.clear();
```


### 第三方账号登陆
第三方账号可以通过自己的账号token登陆蜻蜓SDK
```java
   QTSDK.thirdPartLogin("", new QTAuthCallBack() {
        @Override
        public void onComplete(UserToken response) {
        //授权成功
        Toast.makeText(getBaseContext(), "成功", Toast.LENGTH_SHORT).show();
        }
   
        @Override
         public void onException(QTException e) {
        //授权异常，具体查看异常code
          Toast.makeText(getBaseContext(), "失败", Toast.LENGTH_SHORT).show();
           Logger.e(AuthActivity.class.getSimpleName(), e.getMessage());
      }
   
    @Override
    public void onCancel() {
      //用户取消授权
          Toast.makeText(getBaseContext(), "取消授权", Toast.LENGTH_SHORT).show();
      }
    });
```

用户信息
--------
### 获取用户信息
```java
    QTUserCenter.getUserInfo(new QTCallback<UserInfo>() {
                  @Override
                  public void done(UserInfo result, QTException e) {
                      if(result!=null && e!=null){
                          已获取
                      }else{
                          出错或者未登陆
                      }
                  }
              });
```

支付
--------

蜻蜓SDK可以获取的内容分为免费内容与收费内容两部分，其中免费内容无须授权即可直接获取，收费内容则需要用户授权之后购买才可获取。
可以调用sdk的startQTPay方法并传入代购买专辑的商品id，节目id(选填)，支付结果回调来启动蜻蜓支付流程.

```java
if (!TextUtils.isEmpty(QTUserCenter.getQTUserId())) {
                QTSDK.startQTPay(itemId, programId, (result, e) -> {
                    if (result != null) {
                        switch (result) {
                            case "0":
                                result = "成功";
                                break;
                            case "1":
                                result = "失败";
                                break;
                            case "2":
                                result = "取消";
                                break;
                            case "3":
                                result = "未知";
                                break;
                            case "4":
                                result = "已购";
                                break;
                        }
                        Toast.makeText(getBaseContext(), "购买回调状态:"+result, Toast.LENGTH_SHORT).show();
                    } else {
                        //处理异常
                        Toast.makeText(getBaseContext(), "购买回调异常", Toast.LENGTH_SHORT).show();
                    }
                });
            } else {
                Toast.makeText(getBaseContext(), "请先登录", Toast.LENGTH_SHORT).show();
            }
 
```
播放器
--------
播放器为可选项，如需集成播放器需要先初始化，建议放在application中进行
```java
  QTPlay.initial((success, error) -> {
            if (success){
                //初始化成功
            }
        });

```

播放页配置

```
 val player = QTSDK.getPlayer()
 player.prepare(channelId,programId) //播放 如果待播放节目为电台则调用player.prepare(channelId)方法传入电台id，如果待播放节目为专辑则分别传入专辑id于对应的待播放节目id
 player.pause()//暂停播放
 ```
 播放器状态回调
 ```
 val listener = object : QTPlayer.StateChangeListener {
            override fun onPlayStateChange(state: Int) {
                val strMap = mapOf(
                        -1 to "NONE",
                        0 to "LOADING",
                        1 to "PLAYING ",
                        2 to "PAUSED",
                        3 to "ERROR",
                        4 to "EOF"
                )
                tv_state.text = "当前状态:${strMap[state]}"
                if (state == QTPlayer.PlayState.EOF) {
                    next()
                }
            }

            override fun onPlayProgressChange(millis: Int) {
                tv_progress.text = "${millis}"
                if (!isSeeking) {
                    seekbar.progress = millis
                }
            }

            override fun onPlayDurationChange(millis: Int) {
                tv_duration.text = "${millis}"
                seekbar.max = millis
            }
        }
        player.addListener(listener)
```
播放进度控制
```
        seekbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {

            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {
                isSeeking = true
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                isSeeking = false
                player.seekTo(seekBar.progress)
            }

        })
```


常用接口描述
--------

## public static void init(Context context, String clientId, String clientSecret)

初始化蜻蜓SDK, 建议在应用程序初始化时调用

 * **Parameters:**
   * `context` — the context
   * `clientId` — 合作方的ID
   * `clientSecret` — 合作方密码

## public static void thirdPartLogin(String thirdPartToken, QTCallback callback)

授权登陆,如该平台未绑定蜻蜓账号则会触发蜓账号授权页面

 * **Parameters:**
   * `thirdPartToken` — 第三方账号平台token
   * `callback` — 结果回调{@link QTCallback}

## public static void clear()

清除本地登陆态

## public static void authQTAccount()

启动蜻蜓账号授权页面

## public static void requestChannelOndemandList(String categoryId, String podcasterId, int pageIndex, QTCallback<List<Channel>> callback)

获取点播专辑列表

 * **Parameters:**
   * `categoryId` — 分类id 可为空
   * `podcasterId` — 主播id 可为空
   * `pageIndex` — 分页信息从1开始，默认第一页，每页30条
   * `callback` — {@link QTCallback}结果回调,返回类容参考{@link Channel}

## public static void requestChannelOndemandCategories(QTCallback<List<Category>> callback)

获取点播专辑分类

 * **Parameters:** `callback` — {@link QTCallback}结果回调,返回类容参考{@link Category}

## public static void requestChannelOnDemand(int channelId, QTCallback<Channel> callback)

获取点播专辑

 * **Parameters:**
   * `channelId` — 专辑id
   * `callback` — {@link QTCallback}结果回调,返回类容参考{@link Channel}
   
## public static void requestChannelPrmission(int channelId, QTCallback<ChannelPrmission> callback)
   
获取点播专辑权限，回调里会给出当前用户对该专辑的购买情况

 * **Parameters:**
   * `channelId` — 专辑id
   * `callback` — {@link QTCallback}结果回调,返回类容参考{@link ChannelPrmission}

## public static void requestRadioList(int pageIndex, QTCallback<List<Radio>> callback)

获取点播专辑的节目列表

 * **Parameters:**
   * `pageIndex`   分页信息从1开始，默认第一页，每页30条
   * `callback` — {@link QTCallback}结果回调,返回类容参考{@link Radio}

## public static void requestChannelOnDemandProgramList(int pageIndex, QTCallback<List<ChannelProgram>> callback)


获取广播电台列表

 * **Parameters:**
   * `pageIndex` — 分页信息从1开始，默认第一页，每页30条
   * `callback` — {@link QTCallback}结果回调,返回类容参考{@link Radio}

## public static void requestRadioDetails(int radioId, QTCallback<Radio> callback)

获取广播电台

 * **Parameters:**
   * `radioId` — 电台id
   * `callback` — {@link QTCallback}结果回调,返回类容参考{@link Radio}

## public static void requestRadioPorgramList(int radioId, QTCallback<RadioProgramList> callback)

获取广播电台的节目单

 * **Parameters:**
   * `radioId` — 电台id
   * `callback` — {@link QTCallback}结果回调,返回类容参考{@link RadioProgramList}


## public static void requestUserInfo(QTCallback<UserInfo> callback)

获取用户信息

 * **Parameters:** `callback` — {@link QTCallback}结果回调,返回类容参考{@link UserInfo}

## public static void requestFavChannel(QTCallback<FavChannel> callback)

获取用户收藏的专辑

 * **Parameters:** `callback` — {@link QTCallback}结果回调,返回类容参考{@link FavChannel}

## public static void requestPlayHistory(QTCallback<List<PlayHistory>> callback)

收藏专辑

 * **Parameters:** `callback` — {@link QTCallback}结果回调

## public static void addFavChannel(int channelId, QTCallback<Void> callback)

取消收藏

 * **Parameters:** `callback` — {@link QTCallback}结果回调

## public static void  deleteFavChannel(int channelId, QTCallback<Void> callback)

获取用户收听历史

 * **Parameters:** `callback` — {@link QTCallback}结果回调,返回类容参考{@link PlayHistory}

##  public static void requestPlayHistory(QTCallback<List<PlayHistory>> callback)
上传收听历史

 * **Parameters:** `ts` —  播放停止的时间，使用Unix时间戳, e.g. 1393257000
 * **Parameters:** `channelId` — 专辑id
 * **Parameters:** `programId` — 节目id
 * **Parameters:** `playDuration` — 本次播放时长，单位秒
 * **Parameters:** `position` — 播放停止的位置（距节目开头的秒数）
 * **Parameters:** `callback` — {@link QTCallback}结果回调


## public static void addPlayRecord(int ts, int channelId, int programId, float playDuration, float position, QTCallback<Void> callback)

搜索

 * **Parameters:** `keyword` —  关键词
 * **Parameters:** `type` — 类型：查询内容的类型，channel_live(电台)、 channel_ondemand(专辑)、program_ondemand(点播节目)
 * **Parameters:** `categoryId` — 限定专辑分类，不必传
 * **Parameters:** `page` —  分页信息 从1开始
 * **Parameters:** `callback` —  回调，返回类容参考{@link SimpleChannel}


##  public static void search(@NonNull String keyword,@NonNull String type, String categoryId,@NonNull Integer page,@NonNull final QTCallback<QTListEntity<SimpleChannel>> callback)

