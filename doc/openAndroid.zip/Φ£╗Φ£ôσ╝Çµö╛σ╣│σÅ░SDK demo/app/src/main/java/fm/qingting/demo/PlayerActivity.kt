package fm.qingting.demo

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.SeekBar
import fm.qingting.qtsdk.QTSDK
import fm.qingting.qtsdk.player.QTPlayer
import kotlinx.android.synthetic.main.activity_play.*

/**
 * Created by lee on 2018/1/23.
 */

class PlayerActivity : AppCompatActivity() {

    var curIndex = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_play)
        val channelId = intent.getSerializableExtra("channelId") as Int?
        val programIds = intent.getSerializableExtra("programIds") as ArrayList<Int>?
        if (null == channelId) {
            finish()
            return
        }
        val player = QTSDK.getPlayer()
        player.stop()

        val doPlay = {
            val list = programIds
            if (list != null) {
                list.getOrNull(curIndex)?.apply {
                    tv_program_index.text = "当前播放:节目${curIndex + 1}"
                    player.prepare(channelId, this,object:QTPlayer.PrepareCallback{
                        override fun done(isSuccess: Boolean) {
                        }

                    })

                }
            } else {
                player.prepare(channelId)
            }
        }
        val next = {
            ++curIndex
            doPlay()
        }
        val previous = {
            --curIndex
            doPlay()
        }
        val listener = object : QTPlayer.StateChangeListener {
            override fun onPlayStateChange(state: Int) {
                val strMap = mapOf(
                        -1 to "NONE",
                        0 to "LOADING",
                        1 to "PLAYING ",
                        2 to "PAUSED",
                        3 to "ERROR",
                        4 to "EOF",
                        5 to "SOURCE FAIL",
                        6 to "STOPPED"
                )
                tv_state.text = "当前状态:${strMap[state]}"
                if (state == QTPlayer.PlayState.EOF) {
                    next()
                }
            }

            override fun onPlayProgressChange(millis: Int) {
                tv_progress.text = "${millis}"
                if (!isSeeking) {
                    seekbar.progress = millis
                }
            }

            override fun onPlayDurationChange(millis: Int) {
                tv_duration.text = "${millis}"
                seekbar.max = millis
            }
        }
        player.addListener(listener)


        seekbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {

            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {
                isSeeking = true
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                isSeeking = false
                player.seekTo(seekBar.progress)
            }

        })
        btn_play.setOnClickListener {
            when (player.state) {
                QTPlayer.PlayState.PAUSED -> player.play()
                else -> {
                    doPlay()
                }
            }
        }
        btn_pause.setOnClickListener {
            val programId = programIds?.getOrNull(curIndex) ?: 0
            if (programId == 0) {
                player.stop()
            } else {
                player.pause()
            }
        }
        btn_pre.setOnClickListener {
            previous()
        }
        btn_next.setOnClickListener {
            next()
        }
    }

    var isSeeking = false
    override fun onDestroy() {
        super.onDestroy()
    }

    companion object {
        //播放专辑节目需要专辑id跟节目ID，如果播放的是广播，只需要channelId programIs为空就好
        fun start(activity: Activity, channelId: Int, programIds: ArrayList<Int>?) {
            val intent = Intent(activity, PlayerActivity::class.java)
            intent.putExtra("channelId", channelId)
            if (programIds != null && programIds.size != 0) {
                intent.putExtra("programIds", programIds)
            }
            activity.startActivity(intent)
        }
    }
}
