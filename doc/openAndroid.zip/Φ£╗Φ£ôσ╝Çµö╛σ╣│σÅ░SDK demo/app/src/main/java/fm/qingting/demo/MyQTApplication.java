package fm.qingting.demo;

import android.app.Application;
import android.util.Log;

import fm.qingting.qtsdk.QTSDK;
import fm.qingting.qtsdk.play.ICallback;
import fm.qingting.qtsdk.play.QTPlay;
import fm.qingting.qtsdk.player.QTPlayer;

/**
 * Created by lee on 2018/1/12.
 */

public class MyQTApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        QTSDK.setHost("https://open.staging.qingting.fm");
        QTSDK.init(getApplicationContext(), "client id", "client secret");
        QTSDK.setAuthRedirectUrl("http://qttest.qingting.fm");
        QTSDK.Debug = true;
        QTPlay.initial(new ICallback() {
            @Override
            public void callback(boolean success, Exception e) {
                if (success) {
                    QTSDK.getPlayer().addListener(new QTPlayer.StateChangeListener() {
                        @Override
                        public void onPlayStateChange(int state) {
                            Log.d("play status", state + "");
                        }

                        @Override
                        public void onPlayProgressChange(int millis) {
                            Log.d("play process", millis + "");
                        }

                        @Override
                        public void onPlayDurationChange(int millis) {

                        }
                    });
                }
            }
        });
    }
}
