package fm.qingting.demo

import android.test.ApplicationTestCase
import android.util.Log
import com.google.gson.GsonBuilder
import fm.qingting.qtsdk.QTException
import fm.qingting.qtsdk.QTSDK
import fm.qingting.qtsdk.callbacks.QTAuthCallBack
import fm.qingting.qtsdk.callbacks.QTCallback
import fm.qingting.qtsdk.entity.QTListEntity
import fm.qingting.qtsdk.entity.UserToken
import junit.framework.Assert

/**
 * @Description:
 * @Author: qinff
 * @Date: 12:14 2018/3/28
 */
open class TestHelper : ApplicationTestCase<MyQTApplication>(MyQTApplication::class.java) {
    var application: MyQTApplication? = null

    override fun setUp() {
        super.setUp()
        createApplication()
        application = getApplication()

        QTSDK.init(application, "MWVlMmNhMjgtYWUzOS0xMWU2LTkyM2YtMDAxNjNlMDAyMGFk", "MjZiMjEwYzEtNDQyZS0zYzk3LTk4OWYtMGNlZWEzMzgwNGMz")
        QTSDK.Debug = true//开启日志
        QTSDK.setAuthRedirectUrl("http://qttest.qingting.fm")
    }
}

/**
 * @Description:
 * @Author: qinff
 * @Date: 12:25 2018/3/29
 */
class AuthResult(tag: String? = null) : Result<UserToken>(tag), QTAuthCallBack {
    private var isCancel = false
    override fun onComplete(response: UserToken?) {
        done(response, null)
    }

    override fun onException(e: QTException?) {
        done(null, e)
    }

    override fun onCancel() {
        this.isCancel = true
        done(null, null)
    }

    override fun isOk(): Boolean {
        return super.isOk() && !isCancel()
    }

    fun isCancel(): Boolean {
        return isCancel
    }

    companion object {
        val TAG = AuthResult::class.java.simpleName
    }
}


/**
 * @Description:
 * @Author: qinff
 * @Date: 12:25 2018/3/29
 */
open class Result<T>(val tag: String? = null) : QTCallback<T> {
    private var data: T? = null
    private var err: Exception? = null
    private val f = Object()
    private var isFinish = false
    private fun check() {
        synchronized(f) {
            if (!isFinish) {
                f.wait()
            }
        }
    }

    override fun done(result: T?, e: QTException?) {
        synchronized(f) {
            this.data = result
            this.err = e
            isFinish = true
            f.notifyAll()
        }
//        f.set(data)
    }

    fun ok(): T? {
//        f.get()
        check()
        return data
    }


    fun err(): Exception? {
//        f.get()
        check()
        return err
    }

    open fun isOk(): Boolean {
//        f.get()
        check()
        return err == null
    }

    fun printAll(tag: String? = this.tag): Result<T> {
        val buff = StringBuffer("<${tag ?: TAG}>")
        err()?.apply {
            buff.appendln("error=>${toString()}")
        }
        ok()?.apply {
            val json = if (this is List<*>) {
                "[0]=${GSON.toJson(this.firstOrNull())}"
            } else if (this is QTListEntity<*>) {
                "[${this.pagesize}x${this.page}.0]=${GSON.toJson(this.data?.firstOrNull())}"
            } else {
                GSON.toJson(this)
            }
            buff.appendln("data=>${json}")
        }
        Log.d(TAG, buff.toString())
        return this
    }


    fun assertOk(value: Boolean = true): Result<T> {
        Assert.assertEquals(value, isOk())
        return this
    }

    fun assert(expected: Boolean, test: (Result<T>) -> Boolean): Result<T> {
        Assert.assertEquals(expected, test(this))
        return this
    }

    companion object {
        val TAG = Result::class.java.simpleName
        var GSON = GsonBuilder()
                .setPrettyPrinting()
                .create()
    }
}

fun <T> Result<T>.verify() {
    Assert.assertNull(err())
    Assert.assertNotNull(ok())
}

fun <T> QTCallback<T>.getOrThrow(): T? {
    return null
}