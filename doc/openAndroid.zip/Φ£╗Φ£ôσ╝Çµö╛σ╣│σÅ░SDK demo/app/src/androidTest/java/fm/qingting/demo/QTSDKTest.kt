package fm.qingting.demo

import android.test.ApplicationTestCase
import fm.qingting.qtsdk.QTSDK
import fm.qingting.qtsdk.entity.*
import org.junit.Test

/**
 * @Description:
 * @Author: qinff
 * @Date: 12:07 2018/3/28
 */
class QTSDKTest() : ApplicationTestCase<MyQTApplication>(MyQTApplication::class.java) {
    var application: MyQTApplication? = null

    override fun setUp() {
        super.setUp()
        createApplication()
        application = getApplication()

        QTSDK.init(application, "MWVlMmNhMjgtYWUzOS0xMWU2LTkyM2YtMDAxNjNlMDAyMGFk", "MjZiMjEwYzEtNDQyZS0zYzk3LTk4OWYtMGNlZWEzMzgwNGMz")
        QTSDK.Debug = true//开启日志
        QTSDK.setAuthRedirectUrl("http://qttest.qingting.fm")
    }

    @Test
    fun test_thirdPartLogin() {

        AuthResult("test_thirdPartLogin")
                .apply {
                    val token = UserToken()
                    token.accessToken = "TnCwZqEb3dqkL782H4uLoKEjGVvz6p"
                    token.expiresIn = 7200
                    token.userId = "988551579dea772270e5f70829c801ec"
                    token.refreshToken = "SYxAWial9TIwsGMX9OrHCTRVfN1H5Oq1"
                    QTSDK.thirdPartLogin(token, this)
                }
                .assertOk()
                .printAll()
    }

    @Test
    fun test_requestPlayHistory() {
        Result<List<PlayHistory>>()
                .apply {
                    QTSDK.requestPlayHistory(this)
                }
                .assertOk()
                .printAll("test_requestPlayHistory")
    }

    @Test
    fun test_addFavChannel() {
        Result<Void>()
                .apply {
                    QTSDK.addFavChannel(237353, this)
                }
                .assertOk()
                .printAll("test_addFavChannel")
    }

    @Test
    fun test_deleteFavChannel() {
        Result<Void>()
                .apply {
                    QTSDK.deleteFavChannel(237353, this)
                }
                .assertOk()
                .printAll("test_deleteFavChannel")
    }

//    @Test
//    fun test_requestRadioUrl() {
//        Result<Editions>()
//                .apply {
//                    QTSDK.requestRadioUrl(3617, this)
//                }.assertOk()
//                .printAll("test_requestRadioUrl")
//    }

    @Test
    fun test_requestChannelOnDemandCategories() {
        Result<List<Category>>()
                .apply {
                    QTSDK.requestChannelOnDemandCategories(this)
                }
                .assertOk()
                .printAll("test_requestChannelOnDemandCategories")
    }


    @Test
    fun test_requestChannelOnDemandList() {
        Result<QTListEntity<Channel>>()
                .apply {
                    QTSDK.requestChannelOnDemandList(3617, "", 1, this)
                }
                .assertOk()
                .printAll("test_requestChannelOnDemandList")
    }

    @Test
    fun test_requestChannelOnDemand() {
        Result<Channel>()
                .apply {
                    QTSDK.requestChannelOnDemand(227642, this)
                }
                .assertOk()
                .printAll("test_requestChannelOnDemand")
    }

    @Test
    fun test_requestChannelPrmission() {
        Result<ChannelPrmission>()
                .apply {
                    QTSDK.requestChannelPrmission(227642, this)
                }
                .assertOk()
                .printAll("test_requestChannelPrmission")
    }

    @Test
    fun test_requestRadioList() {
        Result<QTListEntity<Radio>>()
                .apply {
                    QTSDK.requestRadioList(1, this)
                }
                .assertOk()
                .printAll("test_requestRadioList")
    }

    @Test
    fun test_requestRadioDetails() {
        Result<Radio>("test_requestRadioDetails")
                .apply {
                    QTSDK.requestRadioDetails(4938, this)
                }
                .assertOk()
                .printAll()
    }

    @Test
    fun test_requestRadioProgramList() {
        Result<RadioProgramList>()
                .apply {
                    QTSDK.requestRadioProgramList(389, this)
                }
                .assertOk()
                .printAll("test_requestRadioProgramList")
    }

//    @Test
//    fun test_requestPodcasterList() {
//        Result<QTListEntity<Podcaster>>()
//                .apply {
//                    QTSDK.requestPodcasterList(1, this)
//                }
//                .assertOk()
//                .printAll("test_requestPodcasterList")
//    }

    @Test
    fun test_requestPodcasterDetails() {
        Result<Podcaster>()
                .apply {
                    QTSDK.requestPodcasterDetails("000040125dad59a9c602a809b72cb6d3", this)
                }
                .assertOk()
                .printAll("test_requestPodcasterDetails")
    }
}
